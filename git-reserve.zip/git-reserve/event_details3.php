<?php
include 'config.php';

// Vérifier si l'ID de l'événement est présent dans l'URL
if(isset($_GET['id'])) {
    $event_id = $_GET['id'];

    // Connexion à la base de données
    $conn = new mysqli(HOST, USERNAME, PASSWORD, DBNAME);
    if ($conn->connect_error) {
        die("Connexion échouée: " . $conn->connect_error);
    }

    // Requête pour récupérer les détails de l'événement
    $sql = "SELECT * FROM Event WHERE id = $event_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $event = $result->fetch_assoc();
    } else {
        echo "Aucun événement trouvé.";
        exit();
    }

    // Fermer la connexion à la base de données
    $conn->close();
} else {
    echo "ID d'événement non spécifié.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Détails de l'Événement</title>
    <!-- Ajoutez ici vos styles spécifiques si nécessaire -->
      <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        h1 {
            color: #333;
            text-align: center;
        }

        .event-details {
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            margin-bottom: 15px;
        }

        p {
            margin-bottom: 10px;
        }

        footer {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }
    </style>
</head>
<body>

    <?php include 'header.html'; ?>

    <h1>Détails de l'événement : <?php echo htmlspecialchars($event['nom']); ?></h1>

    <div>
        <img src='/uploads/<?php echo htmlspecialchars($event["poster"]); ?>' alt='<?php echo htmlspecialchars($event["nom"]); ?>'>
        <p>Ville: <?php echo htmlspecialchars($event["ville"]); ?></p>
        <p>Date: <?php echo htmlspecialchars($event["date_debut"]); ?> - <?php echo htmlspecialchars($event["date_fin"]); ?></p>
        <p>Description: <?php echo htmlspecialchars($event["description"]); ?></p>
        <!-- Ajoutez ici d'autres détails de l'événement selon votre structure de base de données -->
    </div>

    <?php include 'footer.html'; ?>
</body>
</html>
