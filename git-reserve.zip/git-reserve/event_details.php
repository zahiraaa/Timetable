
<?php
// Active l'affichage des erreurs pour le débogage
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'config.php';

// Vérifier si l'ID de l'événement est présent dans l'URL
if (isset($_GET['id'])) {
    $event_id = $_GET['id'];

    // Connexion à la base de données
    $conn = new mysqli(HOST, USERNAME, PASSWORD, DBNAME);
    if ($conn->connect_error) {
        die("Connexion échouée: " . $conn->connect_error);
    }

    // Requête préparée pour récupérer les détails de l'événement
    $stmt = $conn->prepare("SELECT * FROM Event WHERE id = ?");
    $stmt->bind_param("i", $event_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $event = $result->fetch_assoc();
    } else {
        echo "Aucun événement trouvé.";
        exit();
    }

    $conn->close();
} else {
    echo "ID d'événement non spécifié.";
    exit();
}

// Fonction pour formater la date au format Google Calendar
function formatDateForGoogleCalendar($date) {
    // Assumer que $date est dans le format 'Y-m-d H:i:s' et convertir en 'YYYYMMDDTHHmmssZ'
    $dateTime = new DateTime($date);
    return $dateTime->format('Ymd\THis\Z');
}

// Le reste du code HTML commence ici
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Détails de l'Événement</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>

       /* Styles adaptés à partir du code fourni */
        .panel-gradient {
            background: linear-gradient(to right, #DDA0DD, #FFC0CB);
        }
        
        .navbar {
            margin-bottom: 50px;
            border-radius: 0;
        }
        
        .jumbotron {
            margin-bottom: 0;
        }
        
        footer {
            background-color: #f2f2f2;
            padding: 25px;
        }

        /* Nouveau style pour la présentation du produit */
        .product-details {
            display: flex;
            align-items: start;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            margin: 20px auto;
            width: 80%;
        }

        .product-image {
            flex: 1;
            padding-right: 20px;
        }

        .product-image img {
            max-width: 100%;
            border-radius: 5px;
        }

        .product-info {
            flex: 2;
        }
        
        .custom-button {
    padding: 10px 20px;
    font-size: 16px;
    border: none;
    border-radius: 5px;
    background-color: #007BFF;  /* Couleur de fond bleue par défaut */
    color: white;               /* Couleur du texte blanche */
    cursor: pointer;            /* Changement de curseur en forme de main */
    transition: background-color 0.3s; /* Animation douce lors du changement de couleur */
}

.custom-button:hover {
    background-color: #0056b3;  /* Couleur de fond bleu foncé lors du survol */
}

.custom-button:active {
    background-color: #004080;  /* Couleur de fond encore plus foncée lors du clic */
}
    </style>
</head>
<body>

    <?php include 'header.html'; ?>

    <div class="container panel-gradient">
        <h2 class="text-center">Détails de l'événement :</h2>

        <div class="product-details">
            <div class="product-image">
                <img src='/uploads/<?php echo htmlspecialchars($event["poster"]); ?>' alt='<?php echo htmlspecialchars($event["nom"]); ?>'>
            </div>
            <div class="product-info">
                <p><strong>Nom :</strong> <?php echo htmlspecialchars($event["nom"]); ?></p>
                <p><strong>Ville :</strong> <?php echo htmlspecialchars($event["ville"]); ?></p>
                <p><strong>Date :</strong> <?php echo htmlspecialchars($event["date_debut"]); ?> - <?php echo htmlspecialchars($event["date_fin"]); ?></p>
                <p><strong>Description :</strong> <?php echo htmlspecialchars($event["description"]); ?></p>

                <!-- Ajoutez ici d'autres détails de l'événement selon votre structure de base de données -->
                <!-- Bouton Réserver -->
                <button class="custom-button">Réserver</button>

                <!-- Bouton Ajouter au calendrier -->
       
                    <a href="https://www.google.com/calendar/render?action=TEMPLATE&text=<?php echo urlencode($event["nom"]); ?>&dates=<?php echo formatDateForGoogleCalendar($event["date_debut"]); ?>/<?php echo formatDateForGoogleCalendar($event["date_fin"]); ?>&details=<?php echo urlencode($event["description"]); ?>&location=<?php echo urlencode($event["ville"]); ?>&sf=true&output=xml" class="custom-button" target="_blank">Ajouter au calendrier</a>
            </div>
        </div>

        <a href="index.php" class="btn btn-default">Retour à la liste des événements</a>
    </div>

    <?php include 'footer.html'; ?>
</body>
</html>

