<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>
    <style>
    
        h1 {
            text-align: center;
        }
      .signup-button, .login-button {
    display: block;
    width: 50%;
    padding: 10px;
    background-color: #4169E1; /* Couleur bleu pour signup-button */
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin: 10px auto; /* Centrer horizontalement */
}

.signup-button:hover, .login-button:hover {
    background-color: #FF0000 ; /* Rose fuchsia au survol */
}

.signup-button:active, .login-button:active {
    background-color: #FF00FF; /* Rose fuchsia lorsqu'il est cliqué */
}

.small-text {
    text-align: center;
    font-size: 14px; /* Vous pouvez ajuster la taille de la police si nécessaire */
    margin-top: 20px; /* Espace supplémentaire au-dessus du paragraphe */
    margin-bottom: 100px; /* Espace supplémentaire en dessous du paragraphe */
}

    </style>
    
    <!-- Contenu principal de votre page -->
  <header id="header">
    <!-- ... -->
    
    <?php
    // Inclure le contenu de troistrucs.html
    include("header.php");
    ?>

  </header>
  <!-- ... et tous les autres éléments de la page ... -->
</head>

  
<body>
    <h1>Sign Up</h1>
    
    <button class="signup-button">Use your phone/email</button>
    <button class="signup-button">Continue with Facebook</button>
    <button class="signup-button">Continue with Google</button>
    <button class="signup-button">Continue with Twitter</button>
    <button class="login-button">Already have an account? Login </button>
    
    <p class="small-text">By continuing, you agree to our <a href="#">terms of service</a> and acknowledge that you have read our <a href="#">privacy policy</a> to learn how we collect, use, and share your data.</p>
    
    
<?php include 'footer.php'; ?>    
</body>
</html>

