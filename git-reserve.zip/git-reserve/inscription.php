<?php
ob_start(); // Démarrage du tampon de sortie pour éviter les problèmes liés aux en-têtes HTTP
require 'config.php'; // Inclure le fichier de configuration

// Vérifier si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['name'], $_POST['email'], $_POST['password'], $_POST['role'])) {
    // Assignation des variables à partir des données du formulaire
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $role = trim($_POST['role']);

    // Hachage du mot de passe
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    // Génération d'un token de confirmation
    $confirmation_token = bin2hex(random_bytes(50));

    // Créer une connexion à la base de données
    $conn = new mysqli(HOST, USERNAME, PASSWORD, DBNAME);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Préparer la requête d'insertion avec les paramètres liés pour éviter les injections SQL
    $stmt = $conn->prepare("INSERT INTO utilisateurs (nom, email, password_hash, role, email_confirme, created_at, confirmation_token) VALUES (?, ?, ?, ?, 0, NOW(), ?)");
    if ($stmt === false) {
        die("Erreur de préparation de la requête: " . $conn->error);
    }

    // Liaison des paramètres et exécution de la requête
    $stmt->bind_param('sssss', $name, $email, $passwordHash, $role, $confirmation_token);
    if ($stmt->execute()) {
        // Préparation de l'e-mail de confirmation
        $to = $email;
        $subject = 'Confirmation de votre compte';
        $message = "Bonjour $name,\nPour confirmer votre compte, veuillez cliquer sur le lien suivant: https://reserverdaba.ma/confirm.php?token=$confirmation_token";
        $headers = 'From: no-reply@reserverdaba.ma' . "\r\n" .
                    'Reply-To: no-reply@reserverdaba.ma' . "\r\n" .
                    'X-Mailer: PHP/' . phpversion();
        
        // Envoi de l'e-mail
        mail($to, $subject, $message, $headers);
        
        // Redirection vers la page de confirmation
        header('Location: confirmation_page.php');
        exit();
    } else {
        echo "Erreur d'inscription: " . $stmt->error;
    }

    // Fermeture de la déclaration et de la connexion
    $stmt->close();
    $conn->close();
} else {
    echo "Tous les champs sont requis.";
}

// Fin de la tamponisation et envoi des données tamponnées au navigateur
ob_end_flush();
?>

