<!DOCTYPE html>
<html lang="fr">
<head>
    <!-- Meta tags et title -->
    <!-- Styles CSS combinés de header.html et pop.html -->
<style>
/* Styles généraux */
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f4f4f4; /* Couleur de fond pour le reste de la page */
    padding-bottom: 60px; /* Espace au bas de la page */
}

/* Styles du header */
header {
    background-color: #3ab7bf; /* Bleu clair */
    color: white;
    padding: 15px 0;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Ombre légère */
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 0 10%;
}

header h1 {
    margin: 0;
    font-size: 24px;
}

nav ul {
    list-style: none;
    padding: 0;
    display: flex;
    align-items: center;
    margin: 0;
}

nav ul li {
    margin-left: 20px;
}

nav a, button#loginBtn {
    color: white;
    text-decoration: none;
    font-weight: bold;
    background: none;
    border: none;
    cursor: pointer;
}

/* Style pour le bouton de connexion */
button#loginBtn {
    padding: 5px 10px;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

button#loginBtn:hover {
    background-color: #2a9da0; /* Légèrement plus foncé */
}

/* Styles pour la pop-up */
.popup-overlay {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1000;
}

.popup-content {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 400px;
  background: #fff;
  padding: 20px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
  z-index: 1001;
}

/* Styles pour les boutons de la pop-up */
.popup-content button {
  display: block;
  width: calc(100% - 20px);
  margin-top: 10px;
  padding: 10px;
  border: none;
  background: #f1f1f1;
  font-weight: bold;
}

.popup-content button.google { background: #dd4b39; color: white; }
.popup-content button.apple { background: #000; color: white; }
.popup-content button.facebook { background: #3b5998; color: white; }
.popup-content button.email { background: #dbdbdb; }

.popup-content a {
  text-decoration: none;
  color: #007bff;
}

/* Styles additionnels */
.or-text { margin: 20px 0; text-align: center; }
.terms, .close-btn { text-align: center; margin-top: 20px; }
.close-btn { cursor: pointer; font-size: 20px; }

</style>    
</head>
<body>
    <header>
        <!-- Contenu du header existant -->
        <div class="header-content">
            <!-- Autres éléments -->
              <li><a href="index.php">Accueil</a></li>
              <li><a href="inscri.php">s'inscrire</a></li>
            <!-- Remplacez le lien par un bouton ou modifiez le script pour utiliser le lien existant -->
            <button id="loginBtn">Se connecter</button>
        </div>
    </header>

    <!-- Reste du contenu de header.html -->

<!-- La pop-up -->
    <div class="popup-overlay" id="popup">
        <div class="popup-content">
            <h2>Sign in to your account</h2>
            <button class="google">Continue with Google</button>
            <button class="email">Continue with email/username</button>
            <div class="or-text">OR</div>
            <button class="apple">Apple</button>
            <button class="facebook">Facebook</button>
            <div class="terms">
                By joining, you agree to the Terms of Service and to occasionally receive emails from us.
            </div>
            <div class="close-btn" id="closePopup">&times;</div>
        </div>
    </div>

    <!-- Script pour ouvrir et fermer la pop-up -->
    <script>
        document.getElementById('loginBtn').onclick = function() {
            document.getElementById('popup').style.display = 'block';
        }
        document.getElementById('closePopup').onclick = function() {
            document.getElementById('popup').style.display = 'none';
        }
    </script>
</body>
</html>

