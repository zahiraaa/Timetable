<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Découvrez de nouvelles expériences ! Trouvez un événement !</title>
<style>

.card {
    display: flex;
    align-items: center;
    justify-content: space-between;
    border: 1px solid #ccc;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    border-radius: 10px;
    padding: 40px; /* Further increased padding */
    margin: 20px auto; /* Maintain centering */
    width: 90%; /* Further increased width */
    max-width: 1000px; /* Optional: Increase maximum width limit */
}

.card img {
    width: 250px; /* Further increased image size */
    height: auto;
    border-radius: 5px;
    cursor: pointer; /* Change cursor on hover */
    transition: transform 0.3s ease; /* Smooth transition for enlarging effect */
}

.card-info {
    flex-grow: 1;
    padding-left: 40px; /* Further increased padding */
    text-align: left;
}

.card-info h3 {
    margin-top: 0;
    font-size: 1.8em; /* Increase font size */
}

.card img.enlarged {
    transform: scale(1.5); /* Enlarge the image */
    z-index: 10; /* Ensure the image is above other elements */
    position: relative; /* Needed for z-index to work */
}



</style>

</head>
<body>


<?php
// Inclure le fichier de configuration de la base de données
include 'config.php';

// Récupérer les données du formulaire
$date = $_POST['date'];
$ville = $_POST['ville'];
$dateX = $_POST['date'];
// Connexion à la base de données
$conn = new mysqli(HOST, USERNAME, PASSWORD, DBNAME);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connexion échouée: " . $conn->connect_error);
}


// Modifier la requête SQL pour vérifier si dateX est entre date_debut et date_fin
$sql = "SELECT * FROM Event WHERE ville = ? AND date_debut <= ? AND date_fin >= ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $ville, $dateX, $dateX);

// Exécuter la requête
$stmt->execute();
$result = $stmt->get_result();

// Afficher les résultats
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<div class='card'>";
        echo "<img src='/uploads/" . $row["poster"] . "' alt='Poster'>";
        echo "<div class='card-info'>";
        echo "<h3>" . $row["nom"]. "</h3>";
        echo "<p>Ville: " . $row["ville"]. "</p>";
        echo "<p>Date Début: " . $row["date_debut"]. " - Date Fin: " . $row["date_fin"]. "</p>";
        echo "<a href='" . $row["liens"]. "'>Plus d'infos</a>";
        echo "</div>";
        echo "</div>";
    }
} else {
    echo "Aucun événement trouvé.";
}

// Fermer la connexion
$conn->close();
?>


<script>
document.addEventListener('DOMContentLoaded', (event) => {
    document.querySelectorAll('.card img').forEach(img => {
        img.addEventListener('click', function() {
            this.classList.toggle('enlarged');
        });
    });
});
</script>






  </body>
</html>
