<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Confirmation d'inscription</title>
</head>
<body>
    <h1>Confirmation d'inscription</h1>
    <p>Un email de confirmation a été envoyé à votre adresse email. Veuillez cliquer sur le lien contenu dans cet email pour activer votre compte.</p>
</body>
</html>

