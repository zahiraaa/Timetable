
<html>
<head>
    <title>Calendrier de réservation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: white;
            text-align: center;
            margin: 0;
            padding: 0;
            position: relative;
        }

        body::before, body::after {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: #D2B48C;/*tan,brun clair*/
            z-index: -1;
        }

        #next-button {
            position: absolute;
            bottom: 20px; /* Déplacer le bouton en bas */
            right: 20px; /* Déplacer le bouton à droite */
            background-color:  #FF0000;/*rouge*/
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }

        .container {
            max-width: 400px;
            margin: 20px auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 24px;
            color:#FF0000;
        }

        label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        input[type="date"], input[type="text"], input[type="number"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 5px;
        }

        #check-schedule {
            background-color: #FF0000;/*rouge*/
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }

        #check-schedule:hover {
            background-color: #0056b3;/*bleu*/
        }

        #schedule-result {
            margin-top: 20px;
        }
    </style>
    
<?php include 'header.php'; ?>        
</head>
<body>
    <div class="container">
        <h1>Réservation</h1>
        <label for="datepicker">Choisissez une date</label>
        <input type="date" id="datepicker">
        <button id="check-schedule" class="btn btn-dark btn-block">Afficher les événements</button>
        <div id="schedule-result"></div>
    </div>
    
    
    <div class="event-container">
        <div class="description">
            <h3>Description de l'événement</h3>
            <p>Ceci est la description de l'événement. Vous pouvez y ajouter tous les détails pertinents concernant l'événement.</p>
        </div>
        <div class="event-image">
            <img src="1.png" alt="Image de l'événement" width="200">
        </div>
    </div>
    
    
    
<?php include 'footer.php'; ?>    
</body>
</html>

