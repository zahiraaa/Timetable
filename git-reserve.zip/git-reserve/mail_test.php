<?php
$to = 'chouibazahira@gmail.com'; // Remplacez par votre adresse e-mail pour le test
$subject = 'Test Email';
$message = 'Ceci est un message de test.';
$headers = 'From: no-reply@reserverdaba.com' . "\r\n" .
    'Reply-To: no-reply@reserverdaba.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

if(mail($to, $subject, $message, $headers)) {
    echo 'Email sent successfully';
} else {
    echo 'Email sending failed';
}
?>

