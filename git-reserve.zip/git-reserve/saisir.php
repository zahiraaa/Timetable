<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Saisir un événement</title>
    
     <style>
        body {
            font-family: sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        form {
            width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        input,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <form action="saisir_evenement.php" method="post" enctype="multipart/form-data">
        <input type="text" name="nom" required placeholder="Nom de l'événement">
        <input type="date" name="date_debut" required placeholder="Date de début">
        <input type="date" name="date_fin" required placeholder="Date de fin">
        <input type="text" name="liens" required placeholder="Lien vers l'événement">
        <select name="ville" required>
            <option value="">Ville</option>
            <option value="Casablanca">Casablanca</option>
            <option value="Rabat">Rabat</option>
            <option value="Marrakech">Marrakech</option>
            <option value="Fès">Fès</option>
            <option value="Tanger">Tanger</option>
        </select>
        <input type="file" name="poster" accept="image/jpeg,image/png" required placeholder="Image de l'événement">
        <input type="submit" value="Envoyer">
    </form>
</body>
</html>

je veux un très beau code css pour mon code

