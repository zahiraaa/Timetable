// Vous pouvez ajouter du JavaScript pour la validation côté client si nécessaire
document.getElementById('registrationForm').addEventListener('submit', function(event) {
    // Validation exemple
    var name = document.getElementById('name').value;
    if(name.length < 3) {
        alert("Le nom doit contenir au moins 3 caractères.");
        event.preventDefault();
    }
    // Vous pouvez étendre cette validation selon vos besoins
});

