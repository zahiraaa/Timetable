<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Votre Boutique d'Événements</title>
    <style>
/* Styles généraux */
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    line-height: 1.6;
    background: #f4f4f4; /* Couleur de fond pour la page */
}

/* Styles du header */
header {
    background-color: #333;
    color: white;
    padding: 10px 0;
    text-align: center;
}

/* Styles du container d'événements */
.events-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    padding: 20px;
}

/* Styles des cartes d'événements */
.event-card {
    border: 1px solid #ddd;
    border-radius: 10px;
    margin: 10px;
    padding: 15px;
    width: calc(25% - 20px); /* Ajuste à 4 items par ligne */
    text-align: center;
    background: white; /* Fond blanc pour les cartes */
}

.event-card img {
    width: 100%;
    height: auto;
    border-radius: 5px;
}

.event-card h3 {
    margin: 10px 0;
}

.event-card p {
    margin: 5px 0;
}

/* Styles des liens dans les cartes */
.event-card a {
    display: inline-block;
    margin-top: 10px;
    padding: 10px 15px;
    background-color: #007bff; /* Bleu pour les boutons */
    color: white;
    text-decoration: none;
    border-radius: 5px;
}

.event-card a:hover {
    background-color: #0056b3; /* Bleu plus foncé au survol */
}

/* Styles pour les écrans plus petits */
@media only screen and (max-width: 768px) {
    .event-card {
        width: calc(50% - 20px); /* 2 items par ligne sur écrans plus petits */
    }
}

@media only screen and (max-width: 480px) {
    .event-card {
        width: 100%; /* 1 item par ligne sur très petits écrans */
    }
}

/* Styles du footer */
footer {
    background-color: #333;
    color: white;
    text-align: center;
    padding: 20px 0;
    position: relative;
    bottom: 0;
    width: 100%;
}

.footer-content p, .footer-content a {
    margin: 0;
    padding: 5px;
}

    </style>
</head>
<body>

<?php
include 'config.php';
include 'header.html';

$conn = new mysqli(HOST, USERNAME, PASSWORD, DBNAME);
if ($conn->connect_error) {
    die("Connexion échouée: " . $conn->connect_error);
}

$sql = "SELECT * FROM Event";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<div class='events-container'>";
    while($row = $result->fetch_assoc()) {
        echo "<div class='event-card'>";
        echo "<img src='/uploads/" . htmlspecialchars($row["poster"]) . "' alt='" . htmlspecialchars($row["nom"]) . "'>";
        echo "<h3>" . htmlspecialchars($row["nom"]) . "</h3>";
        echo "<p>Ville: " . htmlspecialchars($row["ville"]) . "</p>";
        echo "<p>Date: " . htmlspecialchars($row["date_debut"]) . " - " . htmlspecialchars($row["date_fin"]) . "</p>";
        echo "<a href='" . htmlspecialchars($row["liens"]) . "'>Plus d'infos</a>";
        echo "</div>";
    }
    echo "</div>";
} else {
    echo "Aucun événement trouvé.";
}
$conn->close();
?>

<?php include 'footer.html'; ?>
</body>
</html>

