<?php
ini_set('display_errors', 1); // Active l'affichage des erreurs
error_reporting(E_ALL); // Rapporte toutes les erreurs PHP
ob_start(); // Démarre le tampon de sortie

require 'config.php';

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    $conn = new mysqli(HOST, USERNAME, PASSWORD, DBNAME);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("UPDATE utilisateurs SET email_confirme = 1 WHERE confirmation_token = ?");
    if (!$stmt) {
        echo "Erreur de préparation: " . $conn->error;
        exit(); // Ajout d'une sortie après une erreur
    }

    $stmt->bind_param("s", $token);
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            header('Location: login.php');
            exit();
        } else {
            echo "Ce token de confirmation n'est pas valide ou a déjà été utilisé.";
        }
    } else {
        echo "Erreur lors de la confirmation: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Aucun token de confirmation fourni.";
}

ob_end_flush(); // Envoie le tampon de sortie et éteint la tamponisation
?>

