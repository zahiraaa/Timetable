<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Votre Boutique d'Événements</title>
    <style>
        /* Styles généraux */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            line-height: 1.6;
            background: #f4f4f4;
            color: #333;
        }

        /* Styles du header */
        header {
            background-color: #007bff;
            color: white;
            padding: 10px 0;
            text-align: center;
        }

        /* Styles du titre et du formulaire de recherche */
        .titre {
            color: #007bff;
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
            margin-top: 20px;
        }

        form {
            background-color: #fff;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 500px;
            margin: 20px auto;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #555;
            font-weight: bold;
        }

        .form-group input[type="date"],
        .form-group input[type="text"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-group input[type="submit"] {
            width: 100%;
            background-color: #007bff;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .form-group input[type="submit"]:hover {
            background-color: #0056b3;
        }

        /* Styles du container d'événements */
        .events-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            padding: 20px;
        }

        /* Styles des cartes d'événements */
        .event-card {
            border: 1px solid #ddd;
            border-radius: 10px;
            margin: 10px;
            padding: 15px;
            width: 250px; /* Largeur fixe pour les cartes */
            text-align: center;
            background: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .event-card img {
            height: 250px; /* Hauteur fixe pour les images */
            width: 100%;
            object-fit: cover;
            border-radius: 5px;
        }

        .event-card h3 {
            margin: 10px 0 5px;
            color: #007bff;
        }

        .event-card p {
            margin: 5px 0;
            font-size: 14px;
        }

        .event-card a {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 12px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .event-card a:hover {
            background-color: #0056b3;
        }

        /* Styles du footer */
        footer {
            background-color: #007bff;
            color: white;
            text-align: center;
            padding: 20px 0;
            position: relative;
            width: 100%;
        }

        footer p, footer a {
            margin: 0;
            padding: 5px;
        }
    </style>
</head>
<body>

    <?php include 'header.html'; ?>

    <h1 class="titre">Découvrez de nouvelles expériences ! Trouvez un événement !</h1>

    <form action="recherche_evenements.php" method="post">
        <div class="form-group">
            <label for="date">Date :</label>
            <input type="date" id="date" name="date" class="date" onchange="formatDate(this);">
        </div>

        <div class="form-group">
            <label for="ville">Ville :</label>
            <input type="text" id="ville" name="ville" class="ville">
        </div>

        <input type="hidden" id="formattedDate" name="formattedDate">
        <input type="submit" value="Rechercher">
    </form>

    <script>
        function formatDate(input) {
            var datePart = input.value.split('-');
            var year = datePart[0];
            var month = datePart[1];
            var day = datePart[2];

            document.getElementById('formattedDate').value = day + '/' + month + '/' + year;
        }
    </script>

    <?php
        include 'config.php';

        $conn = new mysqli(HOST, USERNAME, PASSWORD, DBNAME);
        if ($conn->connect_error) {
            die("Connexion échouée: " . $conn->connect_error);
        }


        $sql = "SELECT * FROM Event ORDER BY date_debut";
        $result = $conn->query($sql);
// ... (le reste du code pour afficher les événements)



        if ($result->num_rows > 0) {
            echo "<div class='events-container'>";
            while($row = $result->fetch_assoc()) {
                echo "<div class='event-card'>";
                echo "<img src='/uploads/" . htmlspecialchars($row["poster"]) . "' alt='" . htmlspecialchars($row["nom"]) . "'>";
                echo "<h3>" . htmlspecialchars($row["nom"]) . "</h3>";
                echo "<p>Ville: " . htmlspecialchars($row["ville"]) . "</p>";
                echo "<p>Date: " . htmlspecialchars($row["date_debut"]) . " - " . htmlspecialchars($row["date_fin"]) . "</p>";
                echo "<a href='event_details.php?id=" . htmlspecialchars($row["id"]) . "'>RESERVER</a>";

                echo "</div>";
            }
            echo "</div>";
        } else {
            echo "Aucun événement trouvé.";
        }
        $conn->close();
    ?>

    <?php include 'footer.html'; ?>
</body>
</html>

