<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Détails de l'Événement</title>
    <style>
    
    /* Style de base pour le corps du document */

    * {
        margin: 0;
        padding: 0;
    }

    html, body {
        height: 100%;
    }

    /* Style pour l'en-tête */
    header {
        background-color: #333;
        color: #fff;
        height: 100px;
        padding: 10px;
        text-align: center;
    }

    /* Style pour l'image de l'événement */
    img.event-poster {
        width: 100%;
        height: auto;
    }

    /* Style pour le corps de la page */
    .event-details {
        width: 80%;
        margin: 0 auto;
        height: 100%;
    }

    .event-details h1 {
        text-align: center;
    }

    .event-details .event-info {
        margin-top: 20px;
    }

    .event-details .event-info p {
        font-size: 16px;
    }

    /* Style pour le pied de page */
    footer {
        background-color: #333;
        color: #fff;
        height: 100px;
        padding: 10px;
        text-align: center;
    }

    </style>
</head>
<body>

    <?php include 'header.html'; ?>

    <div class="event-details">
        <h1>Détails de l'événement : <?php echo htmlspecialchars($event['nom']); ?></h1>

        <div class="event-info">
            <img class="event-poster" src='/uploads/<?php echo htmlspecialchars($event["poster"]); ?>' alt='<?php echo htmlspecialchars($event["nom"]); ?>'>
            <p>Ville: <?php echo htmlspecialchars($event["ville"]); ?></p>
            <p>Date: <?php echo htmlspecialchars($event["date_debut"]); ?> - <?php echo htmlspecialchars($event["date_fin"]); ?></p>
            <p>Description: <?php echo htmlspecialchars($event["description"]); ?></p>
        </div>
    </div>

    <?php include 'footer.html'; ?>
</body>
</html>

