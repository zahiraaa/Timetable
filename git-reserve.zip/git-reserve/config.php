<?php
// Définition des constantes pour la connexion à la base de données
define("HOST", "23.88.66.234");         // L'adresse du serveur de base de données
define("DBNAME", "reserver_test_db");   // Le nom de la base de données
define("USERNAME", "reserver_daba");    // Le nom d'utilisateur pour la connexion à la base de données
define("PASSWORD", "chouiba123!");      // Le mot de passe pour la connexion

// Vous pouvez également ajouter d'autres configurations globales ici si nécessaire
?>

