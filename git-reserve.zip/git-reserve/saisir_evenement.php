<?php
// Connexion à la base de données
require 'config.php'; // Utilisation d'un fichier de configuration pour les constantes de connexion

try {
    $pdo = new PDO("mysql:host=" . HOST . ";dbname=" . DBNAME, USERNAME, PASSWORD);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nom = $_POST['nom'];
    $date_debut = $_POST['date_debut'];
    $date_fin = $_POST['date_fin'];
    $liens = $_POST['liens'];
    $ville = $_POST['ville'];

    // Traitement du fichier uploadé
    $posterName = "";
    if (isset($_FILES['poster']) && $_FILES['poster']['error'] == 0) {
        // Ajouter ici des validations supplémentaires si nécessaire (taille, type de fichier, etc.)
        $originalPosterName = $_FILES['poster']['name'];
        $fileTmpName = $_FILES['poster']['tmp_name'];
        $uniqueId = uniqid(); // Générer un identifiant unique
        $posterName = $uniqueId . '_' . $originalPosterName; // Créer un nouveau nom de fichier
        $fileDestination = 'uploads/' . $posterName; // Chemin du fichier dans le dossier uploads
        move_uploaded_file($fileTmpName, $fileDestination);
    }

    // Insertion des données dans la base
    $sql = "INSERT INTO Event (nom, date_debut, date_fin, liens, ville, poster) VALUES (?, ?, ?, ?, ?, ?)";
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$nom, $date_debut, $date_fin, $liens, $ville, $posterName]); // Utiliser $posterName qui contient le nouveau nom de fichier
        echo "Événement enregistré avec succès.";
    } catch (PDOException $e) {
        echo "Erreur lors de l'enregistrement : " . $e->getMessage();
    }
}
?>

