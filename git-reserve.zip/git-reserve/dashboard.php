<?php
session_start();

// Vérifier si l'utilisateur est connecté, sinon le rediriger vers la page de connexion
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Ici, vous pourriez interroger la base de données pour obtenir des informations spécifiques à l'utilisateur
// en utilisant $_SESSION['user_id'] pour récupérer les données de l'utilisateur connecté.

// Inclure les fichiers de configuration ou de fonctions si nécessaire
// require 'config.php';
// require 'functions.php';

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Tableau de Bord</title>
    <!-- Liens vers les feuilles de style CSS -->
    <!-- <link rel="stylesheet" href="path_to_your_stylesheet.css"> -->
</head>
<body>
    <header>
        <h1>Bienvenue sur votre tableau de bord, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h1>
    </header>
    <nav>
        <!-- Menu de navigation pour le tableau de bord -->
        <ul>
            <li><a href="profil.php">Mon Profil</a></li>
            <li><a href="logout.php">Déconnexion</a></li>
        </ul>
    </nav>
    <main>
        <!-- Contenu spécifique au tableau de bord -->
        <p>Voici quelques informations sur votre compte...</p>
        <!-- Vous pourriez inclure des informations telles que les événements à venir, les messages, etc. -->
    </main>
    <footer>
        <!-- Pied de page avec des informations telles que le copyright, les liens vers les réseaux sociaux, etc. -->
        <p>&copy; 2023 Reserverdaba. Tous droits réservés.</p>
    </footer>
</body>
</html>

